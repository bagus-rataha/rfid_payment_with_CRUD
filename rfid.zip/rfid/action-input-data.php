<?php

    require "koneksidb.php";

    if ($_POST['Submit'] == "Submit") {
        $rfid            = htmlspecialchars($_POST['rfid']);
        $nama            = htmlspecialchars($_POST['nama']);
        $alamat          = htmlspecialchars($_POST['alamat']);
        $telepon         = htmlspecialchars($_POST['telepon']);

        //Masukan data ke Table
        $input = "INSERT INTO tb_daftarrfid (rfid, nama, alamat, telepon) VALUES ('" . $rfid . "', '" . $nama . "', '" . $alamat . "', '" . $telepon . "')";
        $koneksi->query($input);

        header("Location: inputdata.php?pesan=berhasil");
    }

?>