<?php 
   
   require "koneksidb.php";

   $ambilrfid	= $_GET["rfid"];
   $ambiltol	= $_GET["tol"];
   date_default_timezone_set('Asia/Jakarta');
   $tgl=date("Y-m-d G:i:s");
   error_reporting(0); 

   	  	// $data = query("SELECT * FROM tabel_monitoring")[0];
		$carirfid	= query("SELECT rfid FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
		$caritol	= query("SELECT nama_tol FROM tb_tol WHERE nama_tol='$ambiltol'")[0];
		if ($carirfid != 0 && $caritol != 0) {
			$carisaldo = query("SELECT tb_daftarrfid.saldo, tb_daftarrfid.flag FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
			$saldosebelum = $carisaldo['saldo'];
			$flag = $carisaldo['flag'];

			$caribayar = query("SELECT bayar FROM tb_tol WHERE nama_tol='$ambiltol'")[0];
			$bayar = $caribayar['bayar'];

			if ( $saldosebelum >= $bayar ) {
				$updatesaldo = "UPDATE tb_daftarrfid SET saldo = saldo - '$bayar' , flag='allow' WHERE tb_daftarrfid.rfid='$ambilrfid'";
				$koneksi->query($updatesaldo);
			} else {
				$updatestatus = "UPDATE tb_daftarrfid SET flag='deny' WHERE tb_daftarrfid.rfid='$ambilrfid'";
				$koneksi->query($updatestatus);
			}

			//INSERT DATA REALTIME PADA TABEL tb_save
			$carisaldoo = query("SELECT saldo FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
			$saldosesudah = $carisaldoo['saldo'];
			$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, nama_tol, saldo_sebelum, saldo_sesudah, status_un) VALUES ('" . $tgl . "', '" . $ambilrfid . "', '$ambiltol', '$saldosebelum', '$saldosesudah', 'adafull')";
			$koneksi->query($sqlsave);

			//UPDATE DATA REALTIME PADA TABEL tb_monitoring		
			$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', nama_tol='$ambiltol',  saldo_sebelum='$saldosebelum', saldo_sesudah='$saldosesudah', status_trouble='adafull'";
			$koneksi->query($sql);
			
			//MENJADIKAN JSON DATA
			//$response = query("SELECT * FROM tb_monitoring")[0];
			$response = query("SELECT tb_daftarrfid.rfid, tb_daftarrfid.nama, tb_daftarrfid.flag, tb_monitoring.*, tb_tol.bayar FROM tb_daftarrfid,tb_monitoring, tb_tol WHERE tb_daftarrfid.rfid='$ambilrfid' AND tb_tol.nama_tol=tb_monitoring.nama_tol" )[0];
			// $datax 		=$response['rfid']
			$result = json_encode($response);
			echo $result;
		} else if ($carirfid != 0 && $caritol == 0) {

			//INSERT DATA REALTIME PADA TABEL tb_save
			$carisaldoo = query("SELECT saldo FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
			$saldoaja = $carisaldoo['saldo'];
			$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, nama_tol, saldo_sebelum, saldo_sesudah, status_un) VALUES ('" . $tgl . "', '" . $ambilrfid . "', 'Unknown_Toll', '$saldoaja', '$saldoaja', 'adarfid')";
			$koneksi->query($sqlsave);

			//UPDATE DATA REALTIME PADA TABEL tb_monitoring		
			$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', nama_tol='Unknown_Toll',  saldo_sebelum='$saldoaja', saldo_sesudah='$saldoaja', status_trouble='adarfid'";
			$koneksi->query($sql);
			
			//MENJADIKAN JSON DATA
			//$response = query("SELECT * FROM tb_monitoring")[0];
			
			$response = query("SELECT tb_daftarrfid.*, tb_monitoring.*, tb_tol.bayar FROM tb_daftarrfid,tb_monitoring, tb_tol WHERE tb_daftarrfid.rfid='$ambilrfid' AND tb_tol.nama_tol=tb_monitoring.nama_tol" )[0];
			// $datax 		=$response['rfid']
			$result = json_encode($response);
			echo $result;
		} else if ($carirfid == 0 && $caritol != 0) {

			//INSERT DATA REALTIME PADA TABEL tb_save
			$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, nama_tol, saldo_sebelum, saldo_sesudah, status_un) VALUES ('" . $tgl . "', '".$ambiltol."', '$ambiltol', 'Tidak Terdaftar', 'Tidak Terdaftar', 'adatol')";
			$koneksi->query($sqlsave);

			//UPDATE DATA REALTIME PADA TABEL tb_monitoring		
			$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', nama_tol='$ambiltol',  saldo_sebelum='0', saldo_sesudah='0', status_trouble='adatol'";
			$koneksi->query($sql);

			//MENJADIKAN JSON DATA
			//$response = query("SELECT * FROM tb_monitoring")[0];
			$response = query("SELECT tb_monitoring.tanggal, tb_monitoring.rfid, tb_monitoring.status_trouble, tb_tol.bayar FROM tb_monitoring, tb_tol WHERE tb_tol.nama_tol=tb_monitoring.nama_tol" )[0];
			// $datax 		=$response['rfid']
			$result = json_encode($response);
			echo $result;
		} else if ($carirfid == 0 && $caritol == 0) {

			//INSERT DATA REALTIME PADA TABEL tb_save
			$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, nama_tol, saldo_sebelum, saldo_sesudah, status_un) VALUES ('" . $tgl . "', '".$ambiltol."', 'Unknown_Toll', 'Tidak Terdaftar', 'Tidak Terdaftar', 'gaadafull')";
			$koneksi->query($sqlsave);

			//UPDATE DATA REALTIME PADA TABEL tb_monitoring		
			$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', nama_tol='Unknwon_Toll',  saldo_sebelum='0', saldo_sesudah='0', status_trouble='gaadafull'";
			$koneksi->query($sql);

			//MENJADIKAN JSON DATA
			//$response = query("SELECT * FROM tb_monitoring")[0];
			$response = query("SELECT * FROM tb_monitoring" )[0];
			// $datax 		=$response['rfid']
			$result = json_encode($response);
			echo $result;
		}



 ?>