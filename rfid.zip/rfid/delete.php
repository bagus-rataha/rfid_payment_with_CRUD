<?php
require "koneksidb.php";
$id    = $_GET['id'];
// $data = query("SELECT * FROM tb_monitoring")[0];
//cek button    
    $input = mysqli_query($koneksi, "DELETE FROM tb_daftarrfid WHERE id='$id'");
    // $input    ="UPDATE tb_daftarrfid SET rfid='$rfid', nama='$nama', alamat='$alamat', telepon='telepon' WHERE nama='$name'";
    $koneksi ->query($input);
			if ($koneksi) {
			//Jika Sukses
			?>
				<script language="JavaScript">
				alert('Data Berhasil Dihapus!');
				document.location='daftarrfid.php';
				</script>
			<?php
			}
			else {
			//Jika Gagal
			echo "Data Gagal Dihapus!, Silahkan diulangi!";
			}
//Tutup koneksi engine MySQL
    //$dbconnect->close();
?>