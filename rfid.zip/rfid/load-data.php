<?php 
   require "koneksidb.php";	
  
    $data = query("SELECT * FROM tb_monitoring")[0];

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>	</title>
 </head>
 <body>

   <div class="row">
                           
		<!-- <div class="col-xl-6 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">TIME</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1"><?=$data["tanggal"];?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div> -->
                            
		<div class="col-xl-6 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">RFID</h5>
					<div class="metric-value d-inline-block">
						<?php 
						$rfid = $data["rfid"];
						?>
						<h1 class="mb-1"><?=$rfid?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div>
		<!-- <div class="col-xl-6 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">Masuk Toll</h5>
					<div class="metric-value d-inline-block">
					<?php $namaa_toll = $data["nama_tol"];?>
						<h1 class="mb-1"><?=$namaa_toll?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div> -->
		<!-- Status -->
		<div class="col-xl-6 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">Status</h5>
					<div class="metric-value d-inline-block">
						<?php
							$status = $data['status_trouble'];
							if ( $status == 'adafull'){
									$datax = query("SELECT * FROM tb_daftarrfid WHERE rfid='$rfid'")[0];
									$flag = $datax['flag'];
									if ( $flag == 'allow' ){
										echo '<h1 class="mb-1">Masuk Toll</h1>';
										echo	"</div>";
										echo	'<div class="metric-label d-inline-block float-right text-success font-weight-bold">';
										echo'<span class="icon-circle-small icon-box-xs text-success bg-succes-light"><i class="fa fa-fw fa-check"></i></span><span class="ml-1"></span>';
										echo	'</div>';
									} else {
										echo '<h1 class="mb-1" style="color:red;">Saldo Tidak Cukup</h1>';
								echo	"</div>";
								echo	'<div class="metric-label d-inline-block float-right text-success font-weight-bold">';
								echo'<span class="icon-circle-small icon-box-xs text-danger bg-danger-light"><i class="fa fa-fw fa-times"></i></span><span class="ml-1"></span>';
								echo	'</div>';
									}
							} else if ( $status == 'adarfid' ){
								echo '<h1 class="mb-1" style="color:red;">Unknown Toll!</h1>';
								echo	"</div>";
								echo	'<div class="metric-label d-inline-block float-right text-success font-weight-bold">';
								echo'<span class="icon-circle-small icon-box-xs text-danger bg-danger-light"><i class="fa fa-fw fa-times"></i></span><span class="ml-1"></span>';
								echo	'</div>';							
							} else if ( $status == 'adatol' ){
								echo '<h1 class="mb-1" style="color:red;">Unknown RFID!</h1>';
								echo	"</div>";
								echo	'<div class="metric-label d-inline-block float-right text-success font-weight-bold">';
								echo'<span class="icon-circle-small icon-box-xs text-danger bg-danger-light"><i class="fa fa-fw fa-times"></i></span><span class="ml-1"></span>';
								echo	'</div>';						
							} else {
								echo '<h1 class="mb-1" style="color:red;">Kesalahan!</h1>';
								echo	"</div>";
								echo	'<div class="metric-label d-inline-block float-right text-success font-weight-bold">';
								echo'<span class="icon-circle-small icon-box-xs text-danger bg-danger-light"><i class="fa fa-fw fa-times"></i></span><span class="ml-1"></span>';
								echo	'</div>';							
							}
						?>
				</div>
			</div>
		</div>
		<!-- Biaya -->
		<!-- <div class="col-lg-4">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">Biaya</h5>
					<div class="metric-value d-inline-block">
					<?php $datay = query("SELECT tb_tol.bayar FROM tb_tol WHERE tb_tol.nama_tol='$namaa_toll'")[0]; ?>
						<h1 class="mb-1">Rp<?=$datay["bayar"];?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div> -->
		<!-- Saldo Sebelum -->
		<!-- <div class="col-4">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">Saldo Sebelum</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1">Rp<?=$data["saldo_sebelum"];?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div> -->
		<!-- Saldo Sesudah -->
		<!-- <div class="col-4">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body">
					<h5 class="text-muted">Saldo Sesudah</h5>
					<div class="metric-value d-inline-block">
						<h1 class="mb-1">Rp<?=$data["saldo_sesudah"];?></h1>
					</div>
					<div class="metric-label d-inline-block float-right text-success font-weight-bold">
						<span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">update</span>
					</div>
				</div>
			</div>
		</div>                          -->
    </div>
	<div class="row">                    
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0 text-center">LOG Data</h3>
              
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered second" style="width:100%;text-align:center;">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Nama</th>
                                    <th>RFID Key</th>
                                    <th>Tol Terakhir</th>
                                    <th>Bayar Tol</th>
                                    <th>Saldo Sebelum</th>
                                    <th>Saldo Sesudah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
								
                                    $datatampil = mysqli_query($koneksi, "SELECT tb_daftarrfid.nama , tb_tol.bayar , tb_simpan.* from tb_simpan , tb_tol, tb_daftarrfid WHERE tb_daftarrfid.rfid=tb_simpan.rfid  AND tb_tol.nama_tol=tb_simpan.nama_tol ORDER BY no DESC LIMIT 5");
                                    $no=1;
                                    if (is_array($datatampil) || is_object($datatampil)){
                                        foreach ($datatampil as $row){
                                            echo "<tr class= bg-white >
                                                    <td>$no</td>
                                                    <td>".$row['tanggal']."</td>
                                                    <td>".$row['nama']."</td>
                                                    <td>".$row['rfid']."</td>
                                                    <td>".$row['nama_tol']."</td>
                                                    <td>".$row['bayar']."</td>
                                                    <td>".$row['saldo_sebelum']."</td>
                                                    <td>".$row['saldo_sesudah']."</td>
                                                </tr>";
                                            $no++;
                                        }
                                    }

                                    $koneksi->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
      
    </div>	

 </body>
 </html>