<div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
								<ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="data-tables.php">Log Data</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="daftarrfid.php">Daftar RFID</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="inputdata.php">Tambah Data</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="register.php">Tambah User</a>
                                    </li>
                                </ul>
                            </li> 
                            <li class="nav-divider">
                                Setting
								<ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>    
                        </ul>
                    </div>
                </nav>
            </div>
        </div>